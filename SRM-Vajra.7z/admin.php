<html>
    <head>
        <title>Admin Page for Registrations</title>
        <style type="text/css">
            
        </style>
    </head>
    <body>
        <?php
            $servername = "127.2.177.2";
            $username = "adminAJXB21q";
            $password = "pYr_qSCTQmtl";
            $dbname = "mysql";
            $conn = new mysqli($servername,$username,$password,$dbname);
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
            $sql = "SELECT * FROM collegereg";
            $row = $conn->query($sql);
            if($row->num_rows > 0)
            {
                echo "thi also works";
                echo "<table><tr><th>Rep Name</th><th>College</th><th>University</th><th>Phone</th><th>E-Mail</th><th>Address</th><th>Sports</th>                   </tr>";
                while($res = $row->fetch_assoc())
                {
                    echo "<tr><td>".$res["repname"]."</td><td>".$res["collegename"]."</td><td>".$res["universitat"]."</td><td>".$res["phone"]."                         </td><td>".$res["email"]."</td><td>".$res["add1"]."<br>".$res["add2"]."<br>".$res["citystate"]." - ".$res["pinoycode"]."</td>";
                    echo "<td></td></tr>";
                }
            }
            $conn->close();
        ?>
    </body>
</html>